package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type DbContext struct {
	client    *dynamodb.Client
	tableName string
}

var (
	db        DbContext
	tableName string = "VisitorCount"
)

type VisitorCount struct {
	Id    string `json:"id" dynamodbav:"id"`
	Count int    `json:"count" dynamodbav:"count"`
}

func (db DbContext) GetVisitorCount(ctx context.Context, id string) (*VisitorCount, error) {
	key, err := attributevalue.Marshal(id)
	if err != nil {
		return nil, err
	}

	response, err := db.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.tableName),
		Key: map[string]types.AttributeValue{
			"id": key,
		},
	})
	if err != nil {
		return nil, err
	}

	if response.Item == nil {
		return nil, nil
	}

	visitorCount := new(VisitorCount)
	err = attributevalue.UnmarshalMap(response.Item, visitorCount)
	if err != nil {
		return nil, err
	}

	return visitorCount, err
}

func clientError(status int) events.APIGatewayV2HTTPResponse {

	return events.APIGatewayV2HTTPResponse{
		StatusCode: status,
		Headers:    *getResponseHeaders(),
		Body:       http.StatusText(status),
	}
}

func serverError(err error) events.APIGatewayV2HTTPResponse {
	log.Println(err.Error())

	return events.APIGatewayV2HTTPResponse{
		StatusCode: http.StatusInternalServerError,
		Headers:    *getResponseHeaders(),
		Body:       http.StatusText(http.StatusInternalServerError),
	}
}

func getResponseHeaders() *map[string]string {
	headers := make(map[string]string)
	headers["Content-Type"] = "application/json"
	headers["Access-Control-Allow-Origin"] = "https://jorislefondeur.com"
	headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"

	return &headers
}

func processGetVisitorCount(ctx context.Context, req events.APIGatewayV2HTTPRequest) events.APIGatewayV2HTTPResponse {
	id, ok := req.PathParameters["id"]
	if !ok {
		return clientError(http.StatusNotFound)
	}

	visitorCount, err := db.GetVisitorCount(ctx, id)
	if err != nil {
		return serverError(err)
	}

	if visitorCount == nil {
		return clientError(http.StatusNotFound)
	}

	response, err := json.Marshal(visitorCount)
	if err != nil {
		return serverError(err)
	}

	return events.APIGatewayV2HTTPResponse{
		StatusCode: http.StatusOK,
		Headers:    *getResponseHeaders(),
		Body:       string(response),
	}
}

func requestHandler(ctx context.Context, req events.APIGatewayV2HTTPRequest) (events.APIGatewayV2HTTPResponse, error) {
	switch req.RequestContext.HTTP.Method {
	case "GET":
		return processGetVisitorCount(ctx, req), nil
	default:
		return clientError(http.StatusMethodNotAllowed), nil
	}
}

func init() {
	cfg, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion("us-east-1"))
	if err != nil {
		panic(fmt.Sprintf("failed to config: %v", err))
	}

	db.client = dynamodb.NewFromConfig(cfg)
	db.tableName = tableName
}

func main() {
	lambda.Start(requestHandler)
}
